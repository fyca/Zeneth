﻿using UnityEngine;
using System.Collections;

public class splashScreen : MonoBehaviour {
	
	public float delayTime = 5f;
	public Texture splashScreenBG;
	private bool finished = false;
	private float timer;
	
	void Start(){
		timer = delayTime;
		StartCoroutine(LoadWhenFinished());	
	}
	
	void OnGUI(){
		GUI.DrawTexture(new Rect(0,0,Screen.width, Screen.height),splashScreenBG);	//Cna replace with you own texture
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if(timer > 0)
		return;
		if(finished)
		Application.LoadLevel ("MainMenu"); // Change to any scene name or number
		
        //timer for load the next scene
        //Might have to adjust the time accordingly to your own splash image or video
		if(timer == 7){
		finished = true;
			
		}
	}
	
	IEnumerator LoadWhenFinished(){
	yield return null;
	finished = true;
	}
}